-- DDL Triggers in SQL Server
USE SQL_TESTING_DB
GO

CREATE  TRIGGER  trRestrictCreateTable 
ON DATABASE
FOR CREATE_TABLE
AS
BEGIN
  PRINT 'YOU CANNOT CREATE A TABLE IN THIS DATABASE'
  ROLLBACK TRANSACTION
END
--============================================================
CREATE TABLE tblTest (ID INT)
--================================================================
CREATE TRIGGER  trRestrictAlterTable  
ON DATABASE
FOR  ALTER_TABLE
AS
BEGIN
  PRINT 'YOU CANNOT ALTER TABLES'
  ROLLBACK TRANSACTION
END
--===================================================================
CREATE TRIGGER  trRestrictDropTable
ON DATABASE
FOR DROP_TABLE
AS
BEGIN
  PRINT 'YOU CANNOT DROP TABLES'
  ROLLBACK TRANSACTION
END
--==============================================================
DROP TRIGGER trRestrictCreateTable ON DATABASE
DROP TRIGGER trRestrictAlterTable ON DATABASE
DROP TRIGGER trRestrictDropTable ON DATABASE
--====================================================================

CREATE TRIGGER trRestrictDDLEvents
ON DATABASE
FOR CREATE_TABLE, ALTER_TABLE, DROP_TABLE
AS
BEGIN 
   PRINT 'You cannot create, alter or drop a table'
   ROLLBACK TRANSACTION
END
--==========================================================================
DISABLE TRIGGER trRestrictDDLEvents ON DATABASE
--===========================================================================
ENABLE TRIGGER trRestrictDDLEvents ON DATABASE
--=============================================================================
CREATE TRIGGER trRenameTable
ON DATABASE
FOR RENAME
AS
BEGIN
    PRINT 'You just renamed something'
END
--==============================================================================
 -- disable the trRestrictDDLEvents trigger: DISABLE TRIGGER trRestrictDDLEvents ON DATABASE

 --========================================================================================
  CREATE TABLE tblTest (ID INT)
  --================================================================================
  sp_rename 'tblTest', 'tblTestChanged'
--===========================================================================================
CREATE TRIGGER trRestrictDDLEvents
ON DATABASE
FOR CREATE_TABLE, ALTER_TABLE, DROP_TABLE
AS
BEGIN 
   PRINT 'You cannot create, alter or drop a table'
   ROLLBACK TRANSACTION
END
--================================================================================================
CREATE TRIGGER trServerScopedDDLTrigger
ON ALL SERVER
FOR CREATE_TABLE, ALTER_TABLE, DROP_TABLE
AS
BEGIN 
   PRINT 'You cannot create, alter or drop a table in any database of this server'
   ROLLBACK TRANSACTION
END
--====================================================================================================
DISABLE TRIGGER trServerScopedDDLTrigger ON ALL SERVER
--=======================================================================================================
ENABLE TRIGGER trServerScopedDDLTrigger ON ALL SERVER 
--========================================================================================================
 DROP TRIGGER trServerScopedDDLTrigger ON ALL SERVER
 --=====================================================================================================
 -- Create the TableAudit table
CREATE TABLE TableAudit
(
    DatabaseName nvarchar(250),
    TableName nvarchar(250),
    EventType nvarchar(250),
    LoginName nvarchar(250),
    SQLCommand nvarchar(2500),
    AuditDateTime datetime
)
Go

-- The following trigger audits all table changes in all databases on a particular Server
CREATE TRIGGER tr_AuditTableChangesInAllDatabases
ON ALL SERVER
FOR CREATE_TABLE, ALTER_TABLE, DROP_TABLE
AS
BEGIN
    DECLARE @EventData XML
    SELECT @EventData = EVENTDATA()

    INSERT INTO SQL_TESTING_DB.dbo.TableAudit
    (DatabaseName, TableName, EventType, LoginName,
     SQLCommand, AuditDateTime)
    VALUES
    (
         @EventData.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'varchar(250)'),
         @EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'varchar(250)'),
         @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(250)'),
         @EventData.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(250)'),
         @EventData.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(2500)'),
         GetDate()
    )
END
--==========================================================================================================
CREATE TABLE MyTestTable
(
    Id INT,
    Name VARCHAR(50),
    Gender VARCHAR(50),
    Salary INT
)
--=========================================================================================================
SELECT * FROM TableAudit 
--============================================================================================================
--<EVENT_INSTANCE>
--  <EventType>CREATE_TABLE</EventType>
--  <PostTime> 2018-10-10 22:05:37.453 </PostTime>
--  <SPID>58</SPID>
--  <ServerName> LAPTOP-2HN3PT8T </ServerName>
--  <LoginName>LAPTOP-2HN3PT8T\Pranaya</LoginName>
--  <UserName>dbo</UserName>
--  <DatabaseName>SQL_TESTING_DB</DatabaseName>
--  <SchemaName>dbo</SchemaName>
--  <ObjectName>MyTestTable</ObjectName>
--  <ObjectType>TABLE</ObjectType>
--  <TSQLCommand>
--    <SetOptions ANSI_NULLS="ON" ANSI_NULL_DEFAULT="ON"
--                ANSI_PADDING="ON" QUOTED_IDENTIFIER="ON"
--                ENCRYPTED="FALSE" />
--    <CommandText>
--     CREATE TABLE MyTestTable
--     (
--       Id INT,
--       Name VARCHAR(50),
--       Gender VARCHAR(50),
--       Salary INT
--      )
--   </CommandText>
--  </TSQLCommand>
--</EVENT_INSTANCE>
--====================================================================================================================  
