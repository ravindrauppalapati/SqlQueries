--Logon Triggers in SQL Server

CREATE TRIGGER tr_Conn_Limit_LogonTriggers
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS
BEGIN
  DECLARE @LoginName NVARCHAR(100)
     SET @LoginName = ORIGINAL_LOGIN()

  IF @LoginName <> 'sa'
       AND
       ( SELECT COUNT(*)
      FROM   sys.dm_exec_sessions
            WHERE  Is_User_Process = 1 AND
      Original_Login_Name = @LoginName
       ) > 2
  BEGIN
    PRINT 'Third session for the user ' + @LoginName + ' is blocked'
    ROLLBACK
  END
END
--======================================================================================
Execute sp_readerrorlog  
--=====================================================================================
DROP TRIGGER tr_Conn_Limit_LogonTriggers ON ALL SERVER
--========================================================================================
CREATE TRIGGER tr_Limit_Connection_After_Office_Hours
ON ALL SERVER WITH EXECUTE AS 'sa'
FOR LOGON
AS
BEGIN
  DECLARE @LoginName NVARCHAR(100)
        SET @LoginName = ORIGINAL_LOGIN()

  IF @LoginName <> 'sa' AND
      (DATEPART(HOUR, GETDATE()) < 9 OR
                  DATEPART (HOUR, GETDATE()) > 18)
  BEGIN
    PRINT 'You are not authorized to login after office hours'
    ROLLBACK
  END
END
--=======================================================================================
CREATE TRIGGER tr_Restrictied_Host_Only
ON ALL SERVER
FOR LOGON
AS
BEGIN
    IF
    (
        -- White list of allowed hostnames are defined here.
        HOST_NAME() NOT IN ('DevHost','QAHost','UATHost','ProdHost')
    )
    BEGIN
        PRINT 'You are not allowed to login from this hostname.'
        ROLLBACK;
    END 
END
--========================================================================================
-- Creates LogonAuditDB database for storing the audit data
CREATE DATABASE LogonAuditDB 
USE LogonAuditDB
GO

-- Creates TableAudit table for logons inside LogonAuditDB
CREATE TABLE TableLogonAudit 
(
    SessionId int,
    LogonTime datetime,
    HostName varchar(50),
    ProgramName varchar(500),
    LoginName varchar(50),
    ClientHost varchar(50)
)
GO

-- Create Logon trigger for storing the User login data
CREATE TRIGGER LogonAuditTrigger
ON ALL SERVER 
FOR LOGON
AS
BEGIN
  DECLARE @LogonTriggerData xml,
      @EventTime datetime,
      @LoginName varchar(50),
      @ClientHost varchar(50),
      @LoginType varchar(50),
      @HostName varchar(50),
      @AppName varchar(500)
 
  SET @LogonTriggerData = EventData()
 
  SET @EventTime = @LogonTriggerData.value('(/EVENT_INSTANCE/PostTime)[1]', 'datetime')
  SET @LoginName = @LogonTriggerData.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(50)')
  SET @ClientHost = @LogonTriggerData.value('(/EVENT_INSTANCE/ClientHost)[1]', 'varchar(50)')
  SET @HostName = HOST_NAME()
  SET @AppName = APP_NAME()
 
  INSERT INTO LogonAuditDB.dbo.TableLogonAudit
  ( 
    SessionId,
    LogonTime,
    HostName,
    ProgramName,
    LoginName,
    ClientHost
  )
  VALUES
  (
    @@spid,
    @EventTime,
    @HostName,
    @AppName,
    @LoginName,
    @ClientHost
  )
END
GO
--=====================================================================================================
<EVENT_INSTANCE>    
  <EventType>event_type</EventType>    
  <PostTime>post_time</PostTime>    
  <SPID>spid</SPID>    
  <ServerName>server_name</ServerName>    
  <LoginName>login_name</LoginName>    
  <LoginType>login_type</LoginType>    
  <SID>sid</SID>    
  <ClientHost>client_host</ClientHost>    
  <IsPooled>is_pooled</IsPooled>    
</EVENT_INSTANCE> 
--==================================================================================================
SELECT * FROM LogonAuditDB.dbo.TableLogonAudit