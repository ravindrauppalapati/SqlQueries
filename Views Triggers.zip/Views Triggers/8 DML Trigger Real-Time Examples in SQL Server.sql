-- DML Trigger Real-Time Examples in SQL Server
-- Create Employee table
CREATE TABLE Employee
(
  Id int Primary Key,
  Name nvarchar(30),
  Salary int,
  Gender nvarchar(10),
  DepartmentId int
)
GO

-- Insert data into Employee table
INSERT INTO Employee VALUES (1,'Pranaya', 5000, 'Male', 3)
INSERT INTO Employee VALUES (2,'Priyanka', 5400, 'Female', 2)
INSERT INTO Employee VALUES (3,'Anurag', 6500, 'male', 1)
INSERT INTO Employee VALUES (4,'sambit', 4700, 'Male', 2)
INSERT INTO Employee VALUES (5,'Hina', 6600, 'Female', 3)
--=======================================================================
-- Create EmployeeAudit Table
CREATE TABLE EmployeeAudit
(
  ID INT IDENTITY(1,1) PRIMARY KEY,
  AuditData VARCHAR(MAX),
  AuditDate DATETIME
)
--======================================================================
CREATE TRIGGER tr_Employee_For_Insert
ON Employee
FOR INSERT
AS
BEGIN 
  DECLARE @ID INT 
  DECLARE @Name VARCHAR(100) 
  DECLARE @AuditData VARCHAR(100) 
  SELECT @ID = ID, @Name = Name FROM INSERTED 
  SET @AuditData = 'New employee Added with ID  = ' + Cast(@ID AS VARCHAR(10)) + ' and Name ' + @Name 
  INSERT INTO EmployeeAudit (AuditData, AuditDate) VALUES(@AuditData, GETDATE())
END
--========================================================================================
INSERT INTO Employee VALUES (6, 'Saroj', 3300, 'Male', 2)

SELECT * FROM EmployeeAudit

--===========================================================================================
CREATE TRIGGER tr_Employee_For_Delete
ON Employee
FOR DELETE
AS
BEGIN 
  DECLARE @ID INT 
  DECLARE @Name VARCHAR(100) 
  DECLARE @AuditData VARCHAR(100) 
  SELECT @ID = ID, @Name = Name FROM DELETED 
  SET @AuditData = 'An employee is deleted with ID  = ' + Cast(@ID AS VARCHAR(10)) + ' and Name = ' + @Name 
  INSERT INTO EmployeeAudit (AuditData, AuditDate)VALUES(@AuditData, GETDATE())
END
--===============================================================================================
DELETE FROM Employee WHERE ID = 6
SELECT * FROM EmployeeAudit
--==============================================================================================
CREATE TRIGGER tr_Employee_For_Update
ON Employee
FOR Update
AS
BEGIN
       
      DECLARE @ID INT
      DECLARE @Old_Name VARCHAR(200), @New_Name VARCHAR(200)
      DECLARE @Old_Salary INT, @New_Salary INT
      DECLARE @Old_Gender VARCHAR(200), @New_Gender VARCHAR(200)
      DECLARE @Old_DepartmenttId INT, @New_DepartmenttId INT
      
      DECLARE @AuditData VARCHAR(MAX) 
      SELECT *
      INTO #UpdatedDataTempTable
      FROM INSERTED
      
      WHILE(Exists(SELECT ID FROM #UpdatedDataTempTable))
      BEGIN
           
            SET @AuditData = '' 
            SELECT TOP 1 @ID = ID, 
              @New_Name = Name, 
              @New_Gender = Gender, 
              @New_Salary = Salary,
              @New_DepartmenttId = DepartmentId
            FROM #UpdatedDataTempTable
           
          
            SELECT @Old_Name = Name, 
          @Old_Gender = Gender, 
          @Old_Salary = Salary, 
          @Old_DepartmenttId = DepartmentId
            FROM DELETED WHERE ID = @ID
   
         
            Set @AuditData = 'Employee with Id = ' + CAST(@ID AS VARCHAR(6)) + ' changed'

     
            IF(@Old_Name <> @New_Name)
      BEGIN
                  Set @AuditData = @AuditData + ' Name from ' + @Old_Name + ' to ' + @New_Name
      END
            
    
            IF(@Old_Gender <> @New_Gender)
      BEGIN
                  Set @AuditData = @AuditData + ' Gender from ' + @Old_Gender + ' to ' + @New_Gender
      END
                
     
            IF(@Old_Salary <> @New_Salary)
      BEGIN
                  Set @AuditData = @AuditData + ' Salary from ' + Cast(@Old_Salary AS VARCHAR(10))+ ' to ' 
            + Cast(@New_Salary AS VARCHAR(10))
      END
            
        
      IF(@Old_DepartmenttId <> @New_DepartmenttId)
      BEGIN
                  Set @AuditData = @AuditData + ' DepartmentId from ' + Cast(@Old_DepartmenttId AS VARCHAR(10))+ ' to ' 
              + Cast(@New_DepartmenttId AS VARCHAR(10))
            END

     
            INSERT INTO EmployeeAudit(AuditData, AuditDate) VALUES(@AuditData, GETDATE())
            
            
            DELETE FROM #UpdatedDataTempTable WHERE ID = @ID
      End
End
--=========================================================================================================