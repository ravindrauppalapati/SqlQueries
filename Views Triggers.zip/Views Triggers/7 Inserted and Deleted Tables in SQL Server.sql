--Inserted and Deleted Tables in SQL Server
-- Create Employee table
CREATE TABLE Employee
(
  Id int Primary Key,
  Name nvarchar(30),
  Salary int,
  Gender nvarchar(10),
  DepartmentId int
)
GO

-- Insert data into Employee table
INSERT INTO Employee VALUES (1,'Pranaya', 5000, 'Male', 3)
INSERT INTO Employee VALUES (2,'Priyanka', 5400, 'Female', 2)
INSERT INTO Employee VALUES (3,'Anurag', 6500, 'male', 1)
INSERT INTO Employee VALUES (4,'sambit', 4700, 'Male', 2)
INSERT INTO Employee VALUES (5,'Hina', 6600, 'Female', 3)
--==================================================================================
CREATE TRIGGER trInsertEmployee 
ON Employee
FOR INSERT
AS
BEGIN
  SELECT * FROM INSERTED
END
--====================================================================================
INSERT INTO Employee VALUES (6, 'Saroj', 7700, 'Male', 2)
--======================================================================================
CREATE TRIGGER trDeleteEmployee 
ON Employee
FOR DELETE
AS
BEGIN
  SELECT * FROM DELETED
END
--=========================================================================================
DELETE FROM Employee WHERE Id = 6
--============================================================================================
-- Create Update Trigger
CREATE TRIGGER trUpdateEmployee 
ON Employee
FOR UPDATE
AS
BEGIN
  SELECT * FROM DELETED
  SELECT * FROM INSERTED
END
--============================================================================================
UPDATE Employee SET Name = 'Sharma', Salary = 8000 WHERE Id = 5
--=================================================================================================
UPDATE Employee SET Salary = 20000 WHERE Gender = 'Male'
--================================================================================================
