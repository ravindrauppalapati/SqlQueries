--Indexed View 
-- Create table Product
CREATE TABLE Product
(
  ProductId INT PRIMARY KEY,
  Name VARCHAR(20),
  UnitPrice INT
)
GO

-- Populate Product table with some test data
INSERT INTO Product VALUES(1, 'Books', 40)
INSERT INTO Product VALUES(2, 'Pens', 30)
INSERT INTO Product VALUES(3, 'Pencils', 10)
GO

-- Create table ProductSales
CREATE TABLE ProductSales
(
  ProductId INT,
  QuantitySold INT
)
GO

-- Populate ProductSales table with some test data
INSERT INTO ProductSales VALUES(1, 10)
INSERT INTO ProductSales VALUES(3, 23)
INSERT INTO ProductSales VALUES(3, 21)
INSERT INTO ProductSales VALUES(2, 12)
INSERT INTO ProductSales VALUES(1, 13)
INSERT INTO ProductSales VALUES(3, 12)
INSERT INTO ProductSales VALUES(2, 13)
INSERT INTO ProductSales VALUES(1, 11)
INSERT INTO ProductSales VALUES(2, 12)
INSERT INTO ProductSales VALUES(1, 14) 
GO
--=============================================================================
CREATE VIEW vwTotalSalesPriceByProduct
WITH SCHEMABINDING
AS
SELECT Name, 
  COUNT_BIG(*) AS TotalTransactions,
  SUM(ISNULL((QuantitySold * UnitPrice), 0)) AS TotalSalesPrice  
FROM dbo.ProductSales prdSales
INNER JOIN dbo.Product prd
ON prd.ProductId = prdSales.ProductId
GROUP BY Name
--===============================================================================
CREATE UNIQUE CLUSTERED 
INDEX UIX_vwTotalSalesPriceByProduct_Name
ON vwTotalSalesPriceByProduct(Name) 
--==========================================================================
Select * from vwTotalSalesPriceByProduct
--==============================================================================
CREATE TABLE Employee(
 [EmployeeID] [int] NOT NULL,
 [EmployeeName] [varchar](50) NULL,
 [EmployeeCode] NUMERIC(18, 0) NOT NULL,
 [JoiningDate] DateTime NOT NULL
);
--================================================================================
DECLARE @CODE NUMERIC(18, 0);
DECLARE @Name VARCHAR(50);
DECLARE @ID INT;
DECLARE @JoiningDate DATETIME;
SET @CODE = 1000;
SET @ID = 1;
WHILE @CODE < 40000
BEGIN
   SET @Name = 'Name - ' + CAST(@ID AS VARCHAR(10))

   IF(@CODE < 5000)
   BEGIN
        SET @JoiningDate = '2012-01-18';
        INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END
   ELSE IF(@CODE < 15000)
   BEGIN
        SET @JoiningDate = '2014-11-05';
        INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END
   ELSE IF(@CODE < 25000)
   BEGIN
        SET @JoiningDate = '2018-05-07';
        INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END
   ELSE IF(@CODE < 30000)
   BEGIN
        SET @JoiningDate = '2016-10-22';
        INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END
   ELSE IF(@CODE < 35000)
   BEGIN
        SET @JoiningDate = '2015-03-18';
        INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END
   ELSE
   BEGIN
       SET @JoiningDate = '2010-09-09';
       INSERT INTO Employee VALUES(@ID, @Name, @CODE, @JoiningDate);
   END

   SET @ID = @ID + 1
   SET @CODE = @CODE + 1
END;
--=============================================================================
SET STATISTICS IO ON;
SELECT JoiningDate, COUNT(*) NoOfJoining FROM Employee GROUP BY JoiningDate;
--===================================================================================
SET STATISTICS IO ON;
INSERT INTO Employee VALUES(39001, 'Name � 39001', '40000', '2010-09-09');
--====================================================================================
CREATE CLUSTERED INDEX IX_Employee_JoiningDate ON Employee (JoiningDate);
--======================================================================================
SET STATISTICS IO ON;
SELECT JoiningDate, COUNT(*) NoOfJoining FROM Employee GROUP BY JoiningDate;
--======================================================================================
SET STATISTICS IO ON;
INSERT INTO Employee VALUES (39002, 'Name � 39002', '40001', '2010-09-09');
--=======================================================================================
CREATE VIEW IndexedView
WITH SCHEMABINDING
AS
SELECT  dbo.Employee.JoiningDate, 
        COUNT_BIG(*) AS NoOfJoining 
 FROM dbo.Employee 
 GROUP BY dbo.Employee.JoiningDate
 --======================================================================================
 CREATE UNIQUE CLUSTERED INDEX IX_IndexedView_JoiningDate ON IndexedView (JoiningDate);
 --==========================================================================================
 SET STATISTICS IO ON;
SELECT JoiningDate, NoOfJoining FROM IndexedView;
--===========================================================================================
SET STATISTICS IO ON;
SELECT JoiningDate, NoOfJoining FROM IndexedView WITH (NOEXPAND);
--===========================================================================================
SET STATISTICS IO ON;
INSERT INTO Employee VALUES(39003, 'Name � 39003', '40002', '2010-09-09');
--==========================================================================================
