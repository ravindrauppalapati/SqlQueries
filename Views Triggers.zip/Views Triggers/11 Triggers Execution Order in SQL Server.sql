-- Triggers Execution Order in SQL Server

CREATE TRIGGER tr_DatabaseScopeDDLTrigger
ON DATABASE
FOR CREATE_TABLE
AS
BEGIN
    Print 'Database Scope DDL Trigger'
END
GO

CREATE TRIGGER tr_ServerScopeDDLTrigger
ON ALL SERVER
FOR CREATE_TABLE
AS
BEGIN
    Print 'Server Scope DDL Trigger'
END
GO
--=========================================================================
CREATE TABLE Employee(ID INT, Name VARCHAR(100))
--=========================================================================
CREATE TRIGGER tr_DatabaseScopeDDLTrigger
ON DATABASE
FOR CREATE_TABLE
AS
BEGIN
    Print 'Database Scope DDL Trigger'
END
GO
--=======================================================================
EXEC sp_settriggerorder
  @triggername = 'tr_DatabaseScopeDDLTrigger1',
  @order = 'FIRST',
  @stmttype = 'CREATE_TABLE',
  @namespace = 'DATABASE'
GO
--=========================================================================
CREATE TABLE Employee1(ID INT, Name VARCHAR(100))
--=========================================================================
