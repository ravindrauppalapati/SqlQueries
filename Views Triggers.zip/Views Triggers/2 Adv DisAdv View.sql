-- Create Department Table
CREATE TABLE Department
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50)
)
GO

-- Populate the Department Table with test data
INSERT INTO Department VALUES(1, 'IT')
INSERT INTO Department VALUES(2, 'HR')
INSERT INTO Department VALUES(3, 'Sales')

-- Create Employee Table
CREATE TABLE Employee
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50),
  Gender VARCHAR(50),
  DOB DATETIME,
  Salary DECIMAL(18,2),
  DeptID INT
)
GO

-- Populate the Employee Table with test data
INSERT INTO Employee VALUES(1, 'Pranaya', 'Male','1996-02-29 10:53:27.060', 25000, 1)
INSERT INTO Employee VALUES(2, 'Priyanka', 'Female','1995-05-25 10:53:27.060', 30000, 2)
INSERT INTO Employee VALUES(3, 'Anurag', 'Male','1995-04-19 10:53:27.060',40000, 2)
INSERT INTO Employee VALUES(4, 'Preety', 'Female','1996-03-17 10:53:27.060', 35000, 3)
INSERT INTO Employee VALUES(5, 'Sambit', 'Male','1997-01-15 10:53:27.060', 27000, 1)
INSERT INTO Employee VALUES(6, 'Hina', 'Female','1995-07-12 10:53:27.060', 33000, 2)
GO
--==================================================================================================
CREATE VIEW vwEmployeesByDepartment
AS
SELECT emp.ID, emp.Name, emp.Salary,  emp.Gender,  dept.Name AS DepartmentName   FROM Employee emp
INNER JOIN Department dept   ON emp.DeptID = dept.ID

--==================================================================================================
CREATE VIEW vwITDepartmentEmployees
AS
SELECT emp.ID, emp.Name, emp.Salary, emp.Gender,  dept.Name AS DepartmentName   FROM Employee emp
INNER JOIN Department dept  ON emp.DeptID = dept.ID   WHERE dept.Name = 'IT'

--=================================================================================================
SELECT * FROM vwITDepartmentEmployees
--====================================================================================================
CREATE VIEW vwEmployeesByDept
AS
SELECT emp.ID, emp.Name, emp.Gender,  DOB,  dept.Name AS DepartmentName  FROM Employee emp
INNER JOIN Department dept   ON emp.DeptID = dept.ID
--=================================================================================================
SELECT * FROM vwEmployeesByDept
--==============================================================================================
CREATE VIEW vwEmployeesCountByDepartment
AS
SELECT dept.Name AS DepartmentName,  COUNT(*) AS TotalEmployees  FROM Employee emp
INNER JOIN Department dept  ON emp.DeptID = dept.ID   GROUP By dept.Name 
--====================================================================================================
SELECT * FROM vwEmployeesCountByDepartment
--=======================================================================================================
-- Create Employee Table
CREATE TABLE Employee
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50),
  Gender VARCHAR(50),
  DOB DATETIME,
  Salary DECIMAL(18,2),
  DeptID INT
)
GO

-- Populate the Employee Table with test data
INSERT INTO Employee VALUES(1, 'Pranaya', 'Male','1996-02-29 10:53:27.060', 25000, 1)
INSERT INTO Employee VALUES(2, 'Priyanka', 'Female','1995-05-25 10:53:27.060', 30000, 2)
INSERT INTO Employee VALUES(3, 'Anurag', 'Male','1995-04-19 10:53:27.060',40000, 2)
INSERT INTO Employee VALUES(4, 'Preety', 'Female','1996-03-17 10:53:27.060', 35000, 3)
INSERT INTO Employee VALUES(5, 'Sambit', 'Male','1997-01-15 10:53:27.060', 27000, 1)
INSERT INTO Employee VALUES(6, 'Hina', 'Female','1995-07-12 10:53:27.060', 33000, 2)
GO
--=========================================================================================================
-- Error: Cannot pass Parameters to a View
CREATE VIEW vwEmployeeDetailsByGender
@Gender varchar(20)
AS
SELECT Id, Name, Gender, DOB, Salary, DeptID FROM  Employee WHERE Gender = @Gender
--==========================================================================================================
CREATE FUNCTION fnEmployeeDetailsByGender
(
  @Gender VARCHAR(20)
)
RETURNS Table
AS
RETURN  
(SELECT Id, Name, Gender, DOB, Salary, DeptID  FROM Employee WHERE Gender = @Gender)
--===========================================================================================================
SELECT * FROM dbo.fnEmployeeDetailsByGender('Male')
--======================================================================================================
CREATE VIEW vwEmployeeDetailsSortedByName
AS
SELECT Id, Name, Gender, DOB, Salary, DeptID  FROM  Employee  ORDER BY Name
--==========================================================================================================
CREATE VIEW vwEmployeeDetailsSortedByName
AS
SELECT TOP 100 PERCENT Id, Name, Gender, DOB, Salary, DeptID FROM  Employee  ORDER BY Name 
--=============================================================================================================
Create Table ##TestTempTable(Id int, Name nvarchar(20), Gender nvarchar(10))

Insert into ##TestTempTable values(101, ABC, 'Male')
Insert into ##TestTempTable values(102, PQR, 'Female')
Insert into ##TestTempTable values(103, XYZ, 'Female')

-- Error: Cannot create a view on Temp Tables
Create View vwOnTempTable
as
Select Id, Name, Gender  from ##TestTempTable
--================================================================================================================
