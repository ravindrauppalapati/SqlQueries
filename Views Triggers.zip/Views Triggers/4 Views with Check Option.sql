--Views with Check Option, Check Encryption and Schema Binding in SQL Server
-- Create Department Table
CREATE TABLE Department
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50)
)
GO

-- Populate the Department Table with test data
INSERT INTO Department VALUES(1, 'IT')
INSERT INTO Department VALUES(2, 'HR')
INSERT INTO Department VALUES(3, 'Sales')

-- Create Employee Table
CREATE TABLE Employee
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50),
  Gender VARCHAR(50),
  DOB DATETIME,
  Salary DECIMAL(18,2),
  DeptID INT
)
GO

-- Populate the Employee Table with test data
INSERT INTO Employee VALUES(1, 'Pranaya', 'Male','1996-02-29 10:53:27.060', 25000, 1)
INSERT INTO Employee VALUES(2, 'Priyanka', 'Female','1995-05-25 10:53:27.060', 30000, 2)
INSERT INTO Employee VALUES(3, 'Anurag', 'Male','1995-04-19 10:53:27.060',40000, 2)
INSERT INTO Employee VALUES(4, 'Preety', 'Female','1996-03-17 10:53:27.060', 35000, 3)
INSERT INTO Employee VALUES(5, 'Sambit', 'Male','1997-01-15 10:53:27.060', 27000, 1)
INSERT INTO Employee VALUES(6, 'Hina', 'Female','1995-07-12 10:53:27.060', 33000, 2)
GO
--==============================================================================================
CREATE VIEW vwITDepartmentEmployees 
AS 
SELECT ID, Name, Gender, DOB, Salary, DeptID  FROM Employee  WHERE DeptID = 1
--===============================================================================================
INSERT INTO vwITDepartmentEmployees (ID, Name, Gender, DOB, Salary, DeptID) VALUES(7, 'Rohit', 'Male','1994-07-24 10:53:27.060', 45000, 2)
--==================================================================================================
SELECT ID, Name, Gender, DOB, Salary, DeptID FROM Employee 
--===================================================================================================
ALTER VIEW vwITDepartmentEmployees 
AS 
SELECT ID, Name, Gender, DOB, Salary, DeptID FROM Employee WHERE DeptID = 1  WITH CHECK OPTION 
--==========================================================================================================
INSERT INTO vwITDepartmentEmployees (ID, Name, Gender, DOB, Salary, DeptID) VALUES(8, 'Mahesh', 'Male','1994-07-24 10:53:27.060', 55000, 2)
--==============================================================================================================
SELECT id, ctext, text FROM 
SYSCOMMENTS 
WHERE ID = OBJECT_ID('vwITDepartmentEmployees')
--==============================================================================================================
ALTER VIEW vwITDepartmentEmployees 
WITH ENCRYPTION
AS 
SELECT ID, Name, Gender, DOB, Salary, DeptID 
FROM Employee 
WHERE DeptID = 1
WITH CHECK OPTION
--===================================================================================================================
SELECT id, ctext, text FROM 
SYSCOMMENTS 
WHERE ID = OBJECT_ID('vwITDepartmentEmployees')
--================================================================================================================
ALTER VIEW vwITDepartmentEmployees 
WITH SCHEMABINDING
AS 
SELECT ID, Name, Gender, DOB, Salary, DeptID 
FROM dbo.Employee 
WHERE DeptID = 1
WITH CHECK OPTION
--====================================================================================================================
DROP TABLE Employee
--=====================================================================================================
ALTER VIEW vwITDepartmentEmployees 
WITH ENCRYPTION, SCHEMABINDING
AS 
SELECT ID, Name, Gender, DOB, Salary, DeptID 
FROM dbo.Employee 
WHERE DeptID = 1
WITH CHECK OPTION

