--Instead Of Trigger in SQL Server
-- Create Department Table
CREATE TABLE Department
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50)
)
GO

-- Populate the Department Table with test data
INSERT INTO Department VALUES(1, 'IT')
INSERT INTO Department VALUES(2, 'HR')
INSERT INTO Department VALUES(3, 'Sales')

-- Create Employee Table
CREATE TABLE Employee
(
  ID INT PRIMARY KEY,
  Name VARCHAR(50),
  Gender VARCHAR(50),
  DOB DATETIME,
  Salary DECIMAL(18,2),
  DeptID INT
)
GO

-- Populate the Employee Table with test data
INSERT INTO Employee VALUES(1, 'Pranaya', 'Male','1996-02-29 10:53:27.060', 25000, 1)
INSERT INTO Employee VALUES(2, 'Priyanka', 'Female','1995-05-25 10:53:27.060', 30000, 2)
INSERT INTO Employee VALUES(3, 'Anurag', 'Male','1995-04-19 10:53:27.060',40000, 2)
INSERT INTO Employee VALUES(4, 'Preety', 'Female','1996-03-17 10:53:27.060', 35000, 3)
INSERT INTO Employee VALUES(5, 'Sambit', 'Male','1997-01-15 10:53:27.060', 27000, 1)
INSERT INTO Employee VALUES(6, 'Hina', 'Female','1995-07-12 10:53:27.060', 33000, 2)
GO
--==================================================================================================
CREATE VIEW vwEmployeeDetails
AS
SELECT emp.ID, emp.Name, Gender, Salary, dept.Name AS Department
FROM Employee emp
INNER JOIN Department dept
ON emp.DeptID = dept.ID
--====================================================================================================
INSERT INTO vwEmployeeDetails VALUES(7, 'Saroj', 'Male', 50000, 'IT')
--====================================================================================================
CREATE TRIGGER tr_vwEmployeeDetails_InsteadOfInsert
ON vwEmployeeDetails
INSTEAD OF INSERT
AS
BEGIN
  DECLARE @DepartmenttId int
 
 
  SELECT @DepartmenttId = dept.ID 
  FROM Department dept
  INNER JOIN INSERTED inst
  on inst.Department = dept.Name
 
  IF(@DepartmenttId is null)
  BEGIN
    RAISERROR('Invalid Department Name. Statement terminated', 16, 1)
    RETURN
  END 
 
  INSERT INTO Employee(ID, Name, Gender, Salary, DeptID)
  SELECT ID, Name, Gender, Salary, @DepartmenttId
  FROM INSERTED
End
--=========================================================================================================
INSERT INTO vwEmployeeDetails VALUES(7, 'Saroj', 'Male', 50000, 'IT')
--==========================================================================================================
SELECT * FROM vwEmployeeDetails
--======================================================================================================
CREATE VIEW vwEmployeeDetails
AS
SELECT emp.ID, emp.Name, Gender, Salary, dept.Name AS Department
FROM Employee emp
INNER JOIN Department dept
ON emp.DeptID = dept.ID
--===========================================================================================================
UPDATE vwEmployeeDetails  
SET Name = 'Kumar', 
  Salary = 45000,
  Department = 'HR'
WHERE Id = 1
--=============================================================================================================
UPDATE vwEmployeeDetails  
SET Department = 'HR'
WHERE Id = 1
--===========================================================================================================
SELECT * FROM vwEmployeeDetails
--===============================================================================================================
SELECT * FROM Department
--=================================================================================================================
UPDATE Department SET Name = 'IT' WHERE ID = 1
--=================================================================================================================
CREATE TRIGGER tr_vwEmployeeDetails_InsteadOfUpdate
ON vwEmployeeDetails
INSTEAD OF UPDATE
AS
BEGIN 
  IF(UPDATE(ID))
  BEGIN
    RAISERROR('Id cannot be changed', 16, 1)
    RETURN
  END
  
  IF(UPDATE(Department)) 
  BEGIN
    DECLARE @DepartmentID INT

    SELECT @DepartmentID = dept.ID
    FROM Department dept
    INNER JOIN INSERTED inst
    ON dept.Name = inst.Department
  
    IF(@DepartmentID is NULL )
    BEGIN
      RAISERROR('Invalid Department Name', 16, 1)
      RETURN
    END
  
    UPDATE Employee set DeptID = @DepartmentID
    FROM INSERTED
    INNER JOIN Employee
    on Employee.ID = inserted.ID
  End
  
  IF(UPDATE(Gender))
  BEGIN
    UPDATE Employee SET Gender = inserted.Gender
    FROM INSERTED
    INNER JOIN Employee
    ON Employee.ID = INSERTED.ID
  END
  
  IF(UPDATE(Salary))
  BEGIN
    UPDATE Employee SET Salary = inserted.Salary
    FROM INSERTED
    INNER JOIN Employee
    ON Employee.ID = INSERTED.ID
  END
   
  IF(UPDATE(Name))
  BEGIN
    UPDATE Employee SET Name = inserted.Name
    FROM INSERTED
    INNER JOIN Employee
    ON Employee.ID = INSERTED.ID
  END
END
--=================================================================================================
UPDATE vwEmployeeDetails SET Department = 'HR' WHERE Id = 1
--=================================================================================================
UPDATE vwEmployeeDetails  
SET Name = 'Preety',
  Gender = 'Female',
  Salary = 44000,
  Department = 'IT'
WHERE Id = 1
--==================================================================================================
CREATE VIEW vwEmployeeDetails
AS
SELECT emp.ID, emp.Name, Gender, Salary, dept.Name AS Department
FROM Employee emp
INNER JOIN Department dept
ON emp.DeptID = dept.ID
--===================================================================================================
DELETE FROM vwEmployeeDetails WHERE ID = 1
--==================================================================================================
CREATE TRIGGER tr_vwEmployeeDetails_InsteadOfDelete
ON vwEmployeeDetails
INSTEAD OF DELETE
AS
BEGIN
  -- Using Inner Join
  DELETE FROM Employee 
  FROM Employee emp
  INNER JOIN DELETED del
  ON emp.ID = del.ID

  -- Using the Subquery
  -- DELETE FROM Employee 
  -- WHERE ID IN (SELECT ID FROM DELETED)
END
--======================================================================================================
DELETE FROM vwEmployeeDetails WHERE ID = 1
--=======================================================================================================
SELECT * FROM vwEmployeeDetails
--========================================================================================================
